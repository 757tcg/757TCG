import React from 'react';
import SevenFiveSevenTCG from './SevenFiveSevenTCG';

function App() {
  return <SevenFiveSevenTCG />;
}

export default App;
