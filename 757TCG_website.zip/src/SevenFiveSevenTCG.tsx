import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from 'lucide-react';

export default function SevenFiveSevenTCG() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white">
      {loading && <div className="fixed inset-0 flex items-center justify-center bg-black"><motion.div animate={{rotate:360}} className="w-24 h-24 border-8 border-orange-500 border-t-white rounded-full"></motion.div></div>}
      <header className="sticky top-0 bg-black/80 border-b border-orange-500 p-4 flex justify-between">
        <h1 className="text-2xl font-bold text-orange-500">757TCG</h1>
      </header>
      <main className="p-6">
        <h2 className="text-4xl mb-6">Welcome to 757TCG</h2>
        <p>New products, singles, bulk, and sealed cards.</p>
      </main>
    </div>
  );
}
